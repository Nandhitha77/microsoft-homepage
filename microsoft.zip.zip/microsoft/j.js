(function(){
  const track=document.getElementById('track'),
        slides=[...track.children],
        dots=document.getElementById('dots'),
        box=document.getElementById('carousel'),
        toggle=document.getElementById('toggle');
  const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  let i=0,timer=null,playing=!reduce;

  slides.forEach((_,n)=>{
    const b=document.createElement('button');
    b.setAttribute('aria-label','Go to slide '+(n+1));
    b.onclick=()=>{go(n);restart();};
    dots.appendChild(b);
  });

  function go(n){
    i=(n+slides.length)%slides.length;
    track.style.transform='translateX('+(-i*100)+'%)';
    [...dots.children].forEach((d,k)=>d.setAttribute('aria-current',k===i));
    slides.forEach((s,k)=>s.setAttribute('aria-hidden',k!==i));
  }
  function start(){stop();if(playing)timer=setInterval(()=>go(i+1),6000);}
  function stop(){clearInterval(timer);}
  function restart(){start();}
  function setPlaying(v){
    playing=v;
    toggle.textContent=v?'II':'\u25B6';
    toggle.setAttribute('aria-label',v?'Pause slideshow':'Play slideshow');
    v?start():stop();
  }

  document.getElementById('prev').onclick=()=>{go(i-1);restart();};
  document.getElementById('next').onclick=()=>{go(i+1);restart();};
  toggle.onclick=()=>setPlaying(!playing);

  box.addEventListener('mouseenter',stop);
  box.addEventListener('mouseleave',()=>{if(playing)start();});
  box.addEventListener('keydown',e=>{
    if(e.key==='ArrowLeft'){go(i-1);restart();}
    if(e.key==='ArrowRight'){go(i+1);restart();}
  });

  let x0=null;
  box.addEventListener('touchstart',e=>{x0=e.touches[0].clientX;},{passive:true});
  box.addEventListener('touchend',e=>{
    if(x0===null)return;
    const dx=e.changedTouches[0].clientX-x0;
    if(Math.abs(dx)>50){go(i+(dx<0?1:-1));restart();}
    x0=null;
  });

  go(0);setPlaying(playing);
})();